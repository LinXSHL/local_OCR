@echo off
title LocalOCR v6.0 - Dual-Engine Offline OCR (Vertical + Traditional Chinese + PDF + Table)
set "SCRIPT_PATH=%~dp0app\LocalOCR.ps1"
if not exist "%SCRIPT_PATH%" (
    echo [ERROR] Missing file: %SCRIPT_PATH%
    pause
    exit /b 1
)
start "" /B "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%SCRIPT_PATH%"
