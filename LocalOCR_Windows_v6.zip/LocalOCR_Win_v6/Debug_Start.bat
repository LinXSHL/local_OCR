@echo off
chcp 65001 >nul
title LocalOCR v6.0 - Debug Console
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0app\LocalOCR.ps1"
if errorlevel 1 (
    echo.
    echo Program exited with error code %errorlevel%.
    pause
)
