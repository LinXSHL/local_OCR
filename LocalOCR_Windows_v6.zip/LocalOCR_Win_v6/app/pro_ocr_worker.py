# -*- coding: utf-8 -*-
"""
LocalOCR v6.0 - RapidOCR 离线专业引擎工作脚本
支持简体中文(CH)、繁体中文(CHINESE_CHT)、英语(EN)、意法西德(LATIN)及竖排/横排文字识别。
"""
import argparse
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


def build_engine(lang_code: str):
    lang_upper = (lang_code or "CH").strip().upper()
    try:
        from rapidocr import RapidOCR, LangRec

        lang_map = {
            "CH": getattr(LangRec, "CH", "ch"),
            "CHINESE_CHT": getattr(LangRec, "CHINESE_CHT", "chinese_cht"),
            "EN": getattr(LangRec, "EN", "en"),
            "LATIN": getattr(LangRec, "LATIN", "latin"),
            "JAPAN": getattr(LangRec, "JAPAN", "japan"),
            "KOREAN": getattr(LangRec, "KOREAN", "korean"),
            "CYRILLIC": getattr(LangRec, "CYRILLIC", "cyrillic"),
        }
        rec_lang = lang_map.get(lang_upper, getattr(LangRec, "CH", "ch"))
        try:
            engine = RapidOCR(params={"Rec.lang_type": rec_lang})
        except Exception:
            engine = RapidOCR()
        return engine, "rapidocr"
    except ImportError:
        from rapidocr_onnxruntime import RapidOCR as LegacyRapidOCR

        return LegacyRapidOCR(), "rapidocr_onnxruntime"


def extract_boxes(result, backend_name: str):
    items = []
    if result is None:
        return items

    if backend_name == "rapidocr":
        boxes = getattr(result, "boxes", None)
        txts = getattr(result, "txts", None)
        scores = getattr(result, "scores", None)
        if boxes is not None and txts is not None:
            for i, txt in enumerate(txts):
                if not txt:
                    continue
                poly = boxes[i]
                xs = [float(p[0]) for p in poly]
                ys = [float(p[1]) for p in poly]
                x_min, x_max = min(xs), max(xs)
                y_min, y_max = min(ys), max(ys)
                sc = float(scores[i]) if (scores is not None and i < len(scores)) else 1.0
                items.append({
                    "text": str(txt),
                    "x": x_min,
                    "y": y_min,
                    "width": max(1.0, x_max - x_min),
                    "height": max(1.0, y_max - y_min),
                    "score": sc,
                })
            return items

    raw = result[0] if isinstance(result, tuple) else result
    if raw:
        for row in raw:
            if not row or len(row) < 2:
                continue
            poly, txt = row[0], row[1]
            sc = float(row[2]) if len(row) >= 3 else 1.0
            if not txt:
                continue
            xs = [float(p[0]) for p in poly]
            ys = [float(p[1]) for p in poly]
            x_min, x_max = min(xs), max(xs)
            y_min, y_max = min(ys), max(ys)
            items.append({
                "text": str(txt),
                "x": x_min,
                "y": y_min,
                "width": max(1.0, x_max - x_min),
                "height": max(1.0, y_max - y_min),
                "score": sc,
            })
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", type=str, default="", help="Path to image file")
    parser.add_argument("--lang", type=str, default="CH", help="Language code: CH, CHINESE_CHT, EN, LATIN, etc.")
    parser.add_argument("--warmup", type=str, default="", help="Comma-separated language codes to pre-download")
    args = parser.parse_args()

    if args.warmup:
        for code in [c.strip() for c in args.warmup.split(",") if c.strip()]:
            print(f"  -> 正在预加载模型 [{code}] ...", flush=True)
            build_engine(code)
            print(f"  -> 模型 [{code}] 已就绪（已缓存至本地，可离线使用）。", flush=True)
        return

    if not args.image or not Path(args.image).is_file():
        print(json.dumps({"ok": False, "error": "Image file not found."}, ensure_ascii=False))
        sys.exit(1)

    try:
        engine, backend_name = build_engine(args.lang)
        res = engine(args.image)
        boxes = extract_boxes(res, backend_name)
        print(json.dumps({"ok": True, "backend": backend_name, "boxes": boxes}, ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
