﻿# LocalOCR v6.0 - Windows 双引擎纯离线多语言 OCR（竖排文字 + 繁体字独立选项 + 影印PDF + 智能表格）
# v6.0 新增：
# 1. 独立「竖排识别」选项：支持「横排」「竖排(右→左·台版/古籍)」「竖排(左→右)」，按列聚类并严格按从上到下、从右到左顺序重组段落
# 2. 独立「繁体字识别」开关：一键切换至繁体中文识别模型（Windows 原生 zh-Hant-TW/HK 或 RapidOCR CHINESE_CHT），可与竖排/横排自由组合

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime

try {
    [void][Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
    [void][Windows.Storage.StorageFolder, Windows.Storage, ContentType=WindowsRuntime]
    [void][Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
    [void][Windows.Storage.CreationCollisionOption, Windows.Storage, ContentType=WindowsRuntime]
    [void][Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]
    [void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
    [void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
    [void][Windows.Globalization.Language, Windows.Globalization, ContentType=WindowsRuntime]
    [void][Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType=WindowsRuntime]
    [void][Windows.Media.Ocr.OcrResult, Windows.Media.Ocr, ContentType=WindowsRuntime]
    [void][Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType=WindowsRuntime]
    [void][Windows.Data.Pdf.PdfPage, Windows.Data.Pdf, ContentType=WindowsRuntime]
    [void][Windows.Data.Pdf.PdfPageRenderOptions, Windows.Data.Pdf, ContentType=WindowsRuntime]
} catch {
    [System.Windows.MessageBox]::Show(
        "无法初始化 Windows 原生 OCR / PDF 组件。请确认当前系统为 Windows 10 或 Windows 11。`r`n`r`n错误详情：$($_.Exception.Message)",
        "LocalOCR 启动失败",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}

# 内嵌 C# 5.0 图像去底色增强 + 竖排重组 + 图文分区与表格重建引擎
$csharpCode = @'
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

public class OcrWordBox
{
    public string Text;
    public double X;
    public double Y;
    public double Width;
    public double Height;

    public double CenterX { get { return X + Width * 0.5; } }
    public double CenterY { get { return Y + Height * 0.5; } }
    public double Right { get { return X + Width; } }
    public double Bottom { get { return Y + Height; } }
}

public class TablePrepResult
{
    public string ProcessedImagePath;
    public double ScaleFactor;
    public int Width;
    public int Height;
}

public class MixedLayoutResult
{
    public string FormattedText;
    public List<List<string>> PrimaryTableGrid;
    public int TableBlockCount;
    public int PrimaryRows;
    public int PrimaryCols;
    public string SummaryInfo;
}

internal class TextChunk
{
    public string Text;
    public double Left;
    public double Right;
    public double Top;
    public double Bottom;
    public double CenterX { get { return (Left + Right) * 0.5; } }
    public double Width { get { return Right - Left; } }
}

internal class VisualLine
{
    public double AvgY;
    public double MinY;
    public double MaxY;
    public List<OcrWordBox> Words;
    public List<TextChunk> Chunks;
}

internal class VerticalColumn
{
    public double AvgX;
    public double MinX;
    public double MaxX;
    public List<OcrWordBox> Words;
}

public static class LocalOcrTableHelper
{
    private static readonly Regex CjkCjkSpace = new Regex(
        @"(?<=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])\s+(?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])",
        RegexOptions.Compiled
    );
    private static readonly Regex CjkDigitSpace = new Regex(
        @"(?<=[\u4e00-\u9fff])\s+(?=[0-9])|(?<=[0-9])\s+(?=[\u4e00-\u9fff])",
        RegexOptions.Compiled
    );
    private static readonly Regex CjkPunctSpace = new Regex(
        @"(?<=[\u4e00-\u9fff0-9])\s+(?=[，。、；：！？）》】”’「」『』])|(?<=[（《【“‘「『])\s+(?=[\u4e00-\u9fff0-9])",
        RegexOptions.Compiled
    );

    public static string CleanCjkSpaces(string text)
    {
        if (string.IsNullOrEmpty(text)) return string.Empty;
        string s = CjkCjkSpace.Replace(text, "");
        s = CjkDigitSpace.Replace(s, "");
        s = CjkPunctSpace.Replace(s, "");
        return s.Trim();
    }

    public static string CropImageNormalized(string inputPath, string outputPath, double normX, double normY, double normW, double normH)
    {
        using (FileStream fs = new FileStream(inputPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        using (Image tmpImg = Image.FromStream(fs))
        using (Bitmap src = new Bitmap(tmpImg))
        {
            int x = Math.Max(0, Math.Min(src.Width - 1, (int)Math.Round(normX * src.Width)));
            int y = Math.Max(0, Math.Min(src.Height - 1, (int)Math.Round(normY * src.Height)));
            int w = Math.Max(10, Math.Min(src.Width - x, (int)Math.Round(normW * src.Width)));
            int h = Math.Max(10, Math.Min(src.Height - y, (int)Math.Round(normH * src.Height)));

            Rectangle cropRect = new Rectangle(x, y, w, h);
            using (Bitmap cropped = new Bitmap(w, h, PixelFormat.Format24bppRgb))
            {
                using (Graphics g = Graphics.FromImage(cropped))
                {
                    g.Clear(Color.White);
                    g.DrawImage(src, new Rectangle(0, 0, w, h), cropRect, GraphicsUnit.Pixel);
                }
                cropped.Save(outputPath, ImageFormat.Png);
            }
        }
        return outputPath;
    }

    public static TablePrepResult PreprocessImage(string inputPath, string outputPath, bool upscaleSmall, bool normalizeBackground, int maxDimension)
    {
        TablePrepResult result = new TablePrepResult();
        result.ScaleFactor = 1.0;

        Bitmap srcBmp = null;
        Bitmap workBmp = null;
        try
        {
            using (FileStream fs = new FileStream(inputPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (Image tmpImg = Image.FromStream(fs))
            {
                srcBmp = new Bitmap(tmpImg);
            }

            int srcW = srcBmp.Width;
            int srcH = srcBmp.Height;
            double scale = 1.0;
            int maxSide = Math.Max(srcW, srcH);

            if (maxSide > maxDimension)
            {
                scale = (double)(maxDimension - 16) / (double)maxSide;
            }
            else if (upscaleSmall && maxSide < 1800)
            {
                scale = Math.Min(2.0, (double)(maxDimension - 16) / (double)maxSide);
            }

            int w = Math.Max(1, (int)Math.Round(srcW * scale));
            int h = Math.Max(1, (int)Math.Round(srcH * scale));
            result.ScaleFactor = scale;
            result.Width = w;
            result.Height = h;

            workBmp = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(workBmp))
            {
                g.Clear(Color.White);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(srcBmp, 0, 0, w, h);
            }

            if (normalizeBackground)
            {
                Rectangle rect = new Rectangle(0, 0, w, h);
                BitmapData bmpData = workBmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
                int stride = bmpData.Stride;
                int totalBytes = stride * h;
                byte[] rgb = new byte[totalBytes];
                Marshal.Copy(bmpData.Scan0, rgb, 0, totalBytes);

                int radius = Math.Max(20, Math.Min(45, (int)Math.Round(30.0 * scale)));
                byte[] rowGray = new byte[w];
                byte[] rowBg = new byte[w];
                int[] dq = new int[w];

                for (int y = 0; y < h; y++)
                {
                    int rowOff = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        int idx = rowOff + x * 3;
                        rowGray[x] = (byte)((rgb[idx + 2] * 77 + rgb[idx + 1] * 150 + rgb[idx] * 29) >> 8);
                    }

                    int head = 0;
                    int tail = 0;
                    int initRight = Math.Min(w - 1, radius);
                    for (int x = 0; x <= initRight; x++)
                    {
                        byte v = rowGray[x];
                        while (tail > head && rowGray[dq[tail - 1]] <= v) tail--;
                        dq[tail++] = x;
                    }

                    for (int x = 0; x < w; x++)
                    {
                        int right = x + radius;
                        if (right < w && right > initRight)
                        {
                            byte v = rowGray[right];
                            while (tail > head && rowGray[dq[tail - 1]] <= v) tail--;
                            dq[tail++] = right;
                        }
                        int left = x - radius;
                        while (tail > head && dq[head] < left) head++;
                        rowBg[x] = rowGray[dq[head]];
                    }

                    for (int x = 0; x < w; x++)
                    {
                        double bg = rowBg[x] < 40 ? 40.0 : (double)rowBg[x];
                        double norm = ((double)rowGray[x] / bg) * 255.0;
                        if (norm > 255.0) norm = 255.0;
                        double stretched = (norm - 75.0) * (255.0 / 150.0);
                        if (stretched < 0.0) stretched = 0.0;
                        else if (stretched > 255.0) stretched = 255.0;
                        byte outVal = (byte)stretched;

                        int idx = rowOff + x * 3;
                        rgb[idx] = outVal;
                        rgb[idx + 1] = outVal;
                        rgb[idx + 2] = outVal;
                    }
                }

                Marshal.Copy(rgb, 0, bmpData.Scan0, totalBytes);
                workBmp.UnlockBits(bmpData);
            }

            workBmp.Save(outputPath, ImageFormat.Png);
            result.ProcessedImagePath = outputPath;
            return result;
        }
        finally
        {
            if (workBmp != null) workBmp.Dispose();
            if (srcBmp != null) srcBmp.Dispose();
        }
    }

    // 专门针对台版/古籍竖排文字的列聚类与阅读顺序重组
    public static MixedLayoutResult ReconstructVerticalText(List<OcrWordBox> words, bool rightToLeft, bool stripCjkSpaces)
    {
        MixedLayoutResult res = new MixedLayoutResult();
        res.FormattedText = string.Empty;
        res.PrimaryTableGrid = null;
        res.TableBlockCount = 0;
        res.PrimaryRows = 0;
        res.PrimaryCols = 0;
        res.SummaryInfo = "竖排无文字";

        if (words == null || words.Count == 0) return res;

        // 估算典型单列宽度（使用词块宽度的中位数）
        List<double> widths = new List<double>();
        foreach (OcrWordBox w in words)
        {
            if (w.Width > 0) widths.Add(w.Width);
        }
        widths.Sort();
        double medianW = widths.Count > 0 ? widths[widths.Count / 2] : 24.0;
        double colTol = Math.Max(10.0, medianW * 0.65);

        // 按水平中心 X 聚类为竖列
        List<OcrWordBox> sortedByX = new List<OcrWordBox>(words);
        sortedByX.Sort(delegate(OcrWordBox a, OcrWordBox b) { return a.CenterX.CompareTo(b.CenterX); });

        List<VerticalColumn> cols = new List<VerticalColumn>();
        foreach (OcrWordBox w in sortedByX)
        {
            int bestIdx = -1;
            double bestDist = double.MaxValue;
            for (int i = 0; i < cols.Count; i++)
            {
                double d = Math.Abs(w.CenterX - cols[i].AvgX);
                // 若水平区间有明显重叠或中心距离在列宽容差内，则归入同一竖列
                double overlap = Math.Min(w.Right, cols[i].MaxX) - Math.Max(w.X, cols[i].MinX);
                double minW = Math.Max(1.0, Math.Min(w.Width, cols[i].MaxX - cols[i].MinX));
                if ((d <= colTol || (overlap / minW) >= 0.45) && d < bestDist)
                {
                    bestDist = d;
                    bestIdx = i;
                }
            }
            if (bestIdx >= 0)
            {
                VerticalColumn vc = cols[bestIdx];
                vc.Words.Add(w);
                double sumX = 0;
                foreach (OcrWordBox cw in vc.Words) sumX += cw.CenterX;
                vc.AvgX = sumX / vc.Words.Count;
                if (w.X < vc.MinX) vc.MinX = w.X;
                if (w.Right > vc.MaxX) vc.MaxX = w.Right;
            }
            else
            {
                VerticalColumn vc = new VerticalColumn();
                vc.Words = new List<OcrWordBox>();
                vc.Words.Add(w);
                vc.AvgX = w.CenterX;
                vc.MinX = w.X;
                vc.MaxX = w.Right;
                cols.Add(vc);
            }
        }

        // 台版书按从右到左 (AvgX 降序)，左→右竖排按 AvgX 升序
        if (rightToLeft)
        {
            cols.Sort(delegate(VerticalColumn a, VerticalColumn b) { return b.AvgX.CompareTo(a.AvgX); });
        }
        else
        {
            cols.Sort(delegate(VerticalColumn a, VerticalColumn b) { return a.AvgX.CompareTo(b.AvgX); });
        }

        StringBuilder sb = new StringBuilder();
        foreach (VerticalColumn vc in cols)
        {
            // 每列内部按从上到下排序
            vc.Words.Sort(delegate(OcrWordBox a, OcrWordBox b) { return a.Y.CompareTo(b.Y); });
            StringBuilder colSb = new StringBuilder();
            for (int i = 0; i < vc.Words.Count; i++)
            {
                if (i > 0) colSb.Append(" ");
                colSb.Append(vc.Words[i].Text);
            }
            string colText = colSb.ToString().Trim();
            if (stripCjkSpaces) colText = CleanCjkSpaces(colText);
            if (colText.Length > 0) sb.AppendLine(colText);
        }

        res.FormattedText = sb.ToString().Trim();
        res.SummaryInfo = string.Format("竖排识别（{0}）：共 {1} 列", rightToLeft ? "右→左" : "左→右", cols.Count);
        return res;
    }

    public static MixedLayoutResult ReconstructLayout(List<OcrWordBox> words, bool forceWholeAsTable, string tableFormat, bool stripCjkSpaces)
    {
        MixedLayoutResult res = new MixedLayoutResult();
        res.FormattedText = string.Empty;
        res.PrimaryTableGrid = null;
        res.TableBlockCount = 0;
        res.PrimaryRows = 0;
        res.PrimaryCols = 0;
        res.SummaryInfo = "无文字";

        if (words == null || words.Count == 0) return res;

        List<double> heights = new List<double>();
        foreach (OcrWordBox w in words)
        {
            if (w.Height > 0) heights.Add(w.Height);
        }
        heights.Sort();
        double medianH = heights.Count > 0 ? heights[heights.Count / 2] : 20.0;

        List<VisualLine> lines = GroupIntoVisualLines(words, medianH);

        double colGapThreshold = Math.Max(14.0, medianH * 2.1);
        foreach (VisualLine vl in lines)
        {
            vl.Chunks = SplitLineIntoChunks(vl.Words, colGapThreshold, stripCjkSpaces);
        }

        if (forceWholeAsTable)
        {
            List<List<string>> grid = AlignTableLinesByProjection(lines, medianH, stripCjkSpaces);
            res.PrimaryTableGrid = grid;
            res.TableBlockCount = grid.Count > 0 ? 1 : 0;
            res.PrimaryRows = grid.Count;
            res.PrimaryCols = grid.Count > 0 ? grid[0].Count : 0;
            res.FormattedText = FormatTable(grid, tableFormat);
            res.SummaryInfo = string.Format("纯表格识别：{0} 行 × {1} 列", res.PrimaryRows, res.PrimaryCols);
            return res;
        }

        int n = lines.Count;
        bool[] isMultiCol = new bool[n];
        for (int i = 0; i < n; i++) isMultiCol[i] = (lines[i].Chunks.Count >= 2);

        bool[] inTable = new bool[n];
        int idx = 0;
        while (idx < n)
        {
            if (isMultiCol[idx])
            {
                int start = idx;
                int multiCount = 0;
                int end = idx;
                while (idx < n)
                {
                    if (isMultiCol[idx])
                    {
                        multiCount++;
                        end = idx;
                        idx++;
                    }
                    else if (idx + 1 < n && isMultiCol[idx + 1])
                    {
                        double gapToPrev = lines[idx].MinY - lines[end].MaxY;
                        double gapToNext = lines[idx + 1].MinY - lines[idx].MaxY;
                        if (gapToPrev <= medianH * 2.2 && gapToNext <= medianH * 2.2) idx++;
                        else break;
                    }
                    else break;
                }
                if (multiCount >= 2)
                {
                    for (int k = start; k <= end; k++) inTable[k] = true;
                }
            }
            else idx++;
        }

        StringBuilder sb = new StringBuilder();
        int tableCount = 0;
        List<List<string>> bestTable = null;
        int bestCells = 0;

        int cur = 0;
        while (cur < n)
        {
            if (!inTable[cur])
            {
                string lineText = JoinRowAsPlainText(lines[cur].Words, stripCjkSpaces);
                if (lineText.Length > 0) sb.AppendLine(lineText);
                cur++;
            }
            else
            {
                List<VisualLine> block = new List<VisualLine>();
                while (cur < n && inTable[cur])
                {
                    block.Add(lines[cur]);
                    cur++;
                }
                List<List<string>> grid = AlignTableLinesByProjection(block, medianH, stripCjkSpaces);
                tableCount++;
                int cellScore = grid.Count * (grid.Count > 0 ? grid[0].Count : 0);
                if (cellScore > bestCells)
                {
                    bestCells = cellScore;
                    bestTable = grid;
                }
                if (sb.Length > 0) sb.AppendLine();
                sb.AppendLine(FormatTable(grid, tableFormat));
                sb.AppendLine();
            }
        }

        res.FormattedText = sb.ToString().Trim();
        res.PrimaryTableGrid = bestTable;
        res.TableBlockCount = tableCount;
        if (bestTable != null && bestTable.Count > 0)
        {
            res.PrimaryRows = bestTable.Count;
            res.PrimaryCols = bestTable[0].Count;
            res.SummaryInfo = string.Format("图文分区：检测到 {0} 个表格（主表 {1} 行 × {2} 列）", tableCount, res.PrimaryRows, res.PrimaryCols);
        }
        else
        {
            res.SummaryInfo = string.Format("图文分区：共 {0} 行正文", lines.Count);
        }
        return res;
    }

    private static List<VisualLine> GroupIntoVisualLines(List<OcrWordBox> words, double medianH)
    {
        List<OcrWordBox> sorted = new List<OcrWordBox>(words);
        sorted.Sort(delegate(OcrWordBox a, OcrWordBox b) { return a.CenterY.CompareTo(b.CenterY); });

        List<VisualLine> lines = new List<VisualLine>();
        double rowTol = Math.Max(6.0, medianH * 0.55);

        foreach (OcrWordBox w in sorted)
        {
            int bestIdx = -1;
            double bestDist = double.MaxValue;
            for (int i = 0; i < lines.Count; i++)
            {
                double d = Math.Abs(w.CenterY - lines[i].AvgY);
                if (d <= rowTol && d < bestDist)
                {
                    bestDist = d;
                    bestIdx = i;
                }
            }
            if (bestIdx >= 0)
            {
                VisualLine vl = lines[bestIdx];
                vl.Words.Add(w);
                double sumY = 0;
                foreach (OcrWordBox rw in vl.Words) sumY += rw.CenterY;
                vl.AvgY = sumY / vl.Words.Count;
                if (w.Y < vl.MinY) vl.MinY = w.Y;
                if (w.Bottom > vl.MaxY) vl.MaxY = w.Bottom;
            }
            else
            {
                VisualLine vl = new VisualLine();
                vl.Words = new List<OcrWordBox>();
                vl.Words.Add(w);
                vl.AvgY = w.CenterY;
                vl.MinY = w.Y;
                vl.MaxY = w.Bottom;
                lines.Add(vl);
            }
        }

        lines.Sort(delegate(VisualLine a, VisualLine b) { return a.AvgY.CompareTo(b.AvgY); });
        foreach (VisualLine vl in lines)
        {
            vl.Words.Sort(delegate(OcrWordBox a, OcrWordBox b) { return a.X.CompareTo(b.X); });
        }
        return lines;
    }

    private static List<TextChunk> SplitLineIntoChunks(List<OcrWordBox> rowWords, double gapThreshold, bool stripCjkSpaces)
    {
        List<TextChunk> chunks = new List<TextChunk>();
        if (rowWords == null || rowWords.Count == 0) return chunks;

        List<OcrWordBox> grp = new List<OcrWordBox>();
        foreach (OcrWordBox w in rowWords)
        {
            if (grp.Count == 0) grp.Add(w);
            else
            {
                OcrWordBox prev = grp[grp.Count - 1];
                if (w.X - prev.Right <= gapThreshold) grp.Add(w);
                else
                {
                    chunks.Add(BuildChunk(grp, stripCjkSpaces));
                    grp = new List<OcrWordBox>();
                    grp.Add(w);
                }
            }
        }
        if (grp.Count > 0) chunks.Add(BuildChunk(grp, stripCjkSpaces));
        return chunks;
    }

    private static TextChunk BuildChunk(List<OcrWordBox> grp, bool stripCjkSpaces)
    {
        TextChunk ch = new TextChunk();
        ch.Left = double.MaxValue;
        ch.Right = double.MinValue;
        ch.Top = double.MaxValue;
        ch.Bottom = double.MinValue;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < grp.Count; i++)
        {
            OcrWordBox w = grp[i];
            if (w.X < ch.Left) ch.Left = w.X;
            if (w.Right > ch.Right) ch.Right = w.Right;
            if (w.Y < ch.Top) ch.Top = w.Y;
            if (w.Bottom > ch.Bottom) ch.Bottom = w.Bottom;
            if (i > 0) sb.Append(" ");
            sb.Append(w.Text);
        }
        string t = sb.ToString().Trim();
        ch.Text = stripCjkSpaces ? CleanCjkSpaces(t) : t;
        return ch;
    }

    private static string JoinRowAsPlainText(List<OcrWordBox> rowWords, bool stripCjkSpaces)
    {
        if (rowWords == null || rowWords.Count == 0) return string.Empty;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rowWords.Count; i++)
        {
            if (i > 0) sb.Append(" ");
            sb.Append(rowWords[i].Text);
        }
        string t = sb.ToString().Trim();
        return stripCjkSpaces ? CleanCjkSpaces(t) : t;
    }

    private static List<List<string>> AlignTableLinesByProjection(List<VisualLine> tableLines, double medianH, bool stripCjkSpaces)
    {
        List<List<string>> grid = new List<List<string>>();
        if (tableLines == null || tableLines.Count == 0) return grid;

        double minX = double.MaxValue;
        double maxX = double.MinValue;
        foreach (VisualLine vl in tableLines)
        {
            foreach (TextChunk ch in vl.Chunks)
            {
                if (ch.Left < minX) minX = ch.Left;
                if (ch.Right > maxX) maxX = ch.Right;
            }
        }
        if (minX >= maxX) return grid;

        int binStep = 2;
        int numBins = Math.Max(1, (int)Math.Ceiling((maxX - minX) / binStep) + 1);
        int[] occ = new int[numBins];

        foreach (VisualLine vl in tableLines)
        {
            if (vl.Chunks.Count == 1 && vl.Chunks[0].Width > (maxX - minX) * 0.85) continue;
            foreach (TextChunk ch in vl.Chunks)
            {
                int b1 = Math.Max(0, (int)Math.Floor((ch.Left - minX) / binStep));
                int b2 = Math.Min(numBins - 1, (int)Math.Ceiling((ch.Right - minX) / binStep));
                for (int b = b1; b <= b2; b++) occ[b]++;
            }
        }

        int minValleyBins = Math.Max(4, (int)Math.Round((medianH * 1.5) / binStep));
        List<double> splits = new List<double>();
        int vStart = -1;
        for (int b = 0; b < numBins; b++)
        {
            if (occ[b] == 0)
            {
                if (vStart < 0) vStart = b;
            }
            else
            {
                if (vStart >= 0)
                {
                    if (vStart > 0 && (b - vStart) >= minValleyBins)
                    {
                        splits.Add(minX + ((vStart + b - 1) * 0.5) * binStep);
                    }
                    vStart = -1;
                }
            }
        }

        int colCount = splits.Count + 1;
        foreach (VisualLine vl in tableLines)
        {
            List<OcrWordBox>[] colWords = new List<OcrWordBox>[colCount];
            for (int c = 0; c < colCount; c++) colWords[c] = new List<OcrWordBox>();

            foreach (OcrWordBox w in vl.Words)
            {
                int cIdx = 0;
                while (cIdx < splits.Count && w.CenterX >= splits[cIdx]) cIdx++;
                colWords[cIdx].Add(w);
            }

            List<string> rowCells = new List<string>();
            for (int c = 0; c < colCount; c++)
            {
                rowCells.Add(JoinRowAsPlainText(colWords[c], stripCjkSpaces));
            }
            grid.Add(rowCells);
        }

        return grid;
    }

    public static string FormatTable(List<List<string>> grid, string format)
    {
        if (grid == null || grid.Count == 0) return string.Empty;
        int colCount = 0;
        foreach (List<string> r in grid)
        {
            if (r.Count > colCount) colCount = r.Count;
        }
        if (colCount == 0) return string.Empty;

        StringBuilder sb = new StringBuilder();
        if (format == "Markdown")
        {
            for (int r = 0; r < grid.Count; r++)
            {
                sb.Append("|");
                for (int c = 0; c < colCount; c++)
                {
                    string val = (c < grid[r].Count ? grid[r][c] : "").Replace("|", "\\|").Replace("\r", " ").Replace("\n", " ");
                    sb.Append(" ").Append(val).Append(" |");
                }
                sb.AppendLine();
                if (r == 0)
                {
                    sb.Append("|");
                    for (int c = 0; c < colCount; c++) sb.Append(" --- |");
                    sb.AppendLine();
                }
            }
        }
        else if (format == "Aligned")
        {
            int[] widths = new int[colCount];
            for (int r = 0; r < grid.Count; r++)
            {
                for (int c = 0; c < colCount; c++)
                {
                    string val = c < grid[r].Count ? grid[r][c] : "";
                    int w = DisplayWidth(val);
                    if (w > widths[c]) widths[c] = w;
                }
            }
            for (int r = 0; r < grid.Count; r++)
            {
                for (int c = 0; c < colCount; c++)
                {
                    if (c > 0) sb.Append("  |  ");
                    string val = c < grid[r].Count ? grid[r][c] : "";
                    sb.Append(val);
                    int pad = widths[c] - DisplayWidth(val);
                    if (pad > 0) sb.Append(new string(' ', pad));
                }
                sb.AppendLine();
            }
        }
        else if (format == "CSV")
        {
            for (int r = 0; r < grid.Count; r++)
            {
                for (int c = 0; c < colCount; c++)
                {
                    if (c > 0) sb.Append(",");
                    string val = c < grid[r].Count ? grid[r][c] : "";
                    if (val.IndexOf(',') >= 0 || val.IndexOf('"') >= 0 || val.IndexOf('\n') >= 0 || val.IndexOf('\r') >= 0)
                    {
                        sb.Append("\"").Append(val.Replace("\"", "\"\"")).Append("\"");
                    }
                    else sb.Append(val);
                }
                sb.AppendLine();
            }
        }
        else
        {
            for (int r = 0; r < grid.Count; r++)
            {
                for (int c = 0; c < colCount; c++)
                {
                    if (c > 0) sb.Append("\t");
                    string val = (c < grid[r].Count ? grid[r][c] : "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
                    sb.Append(val);
                }
                sb.AppendLine();
            }
        }
        return sb.ToString().TrimEnd('\r', '\n');
    }

    private static int DisplayWidth(string s)
    {
        if (string.IsNullOrEmpty(s)) return 0;
        int w = 0;
        for (int i = 0; i < s.Length; i++) w += (s[i] > 0x2E80) ? 2 : 1;
        return w;
    }
}
'@

try {
    Add-Type -TypeDefinition $csharpCode -ReferencedAssemblies @("System.Drawing") -ErrorAction Stop
} catch {
    [System.Windows.MessageBox]::Show(
        "初始化核心引擎失败：`r`n$($_.Exception.Message)",
        "LocalOCR 启动失败",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}

$script:AsTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and
    $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]

$script:AsTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and
    $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
})[0]

function Await-WinRT {
    param($WinRtTask, [Type]$ResultType)
    $asTask = $script:AsTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    return $netTask.Result
}

function Await-WinRTAction {
    param($WinRtAction)
    $netTask = $script:AsTaskAction.Invoke($null, @($WinRtAction))
    $netTask.Wait(-1) | Out-Null
}

$script:AppDir  = Split-Path -Parent $PSCommandPath
$script:RootDir = Split-Path -Parent $script:AppDir
$script:ProVenvPy = Join-Path $script:RootDir "pro_venv\Scripts\python.exe"
$script:ProWorker = Join-Path $script:AppDir "pro_ocr_worker.py"

$script:FriendlyLangMap = @{
    "zh-Hans-CN" = "简体中文"
    "zh-CN"      = "简体中文"
    "zh-Hant-TW" = "繁体中文 (台湾)"
    "zh-Hant-HK" = "繁体中文 (香港)"
    "zh-TW"      = "繁体中文"
    "en-US"      = "英语 (美国)"
    "en-GB"      = "英语 (英国)"
    "it-IT"      = "意大利语"
    "fr-FR"      = "法语 (法国)"
    "fr-CA"      = "法语 (加拿大)"
    "es-ES"      = "西班牙语 (西班牙)"
    "es-MX"      = "西班牙语 (墨西哥)"
    "de-DE"      = "德语"
    "ja"         = "日语"
    "ja-JP"      = "日语"
    "ko"         = "韩语"
    "ko-KR"      = "韩语"
    "ru"         = "俄语"
    "ru-RU"      = "俄语"
}

$script:ProLanguageList = @(
    @{ Label = "中英混排 / 简体中文 [CH]"; Tag = "CH" },
    @{ Label = "繁体中文 / 台港书籍 [CHINESE_CHT]"; Tag = "CHINESE_CHT" },
    @{ Label = "意大利语/法语/西语/德语 [LATIN]"; Tag = "LATIN" },
    @{ Label = "纯英语 (保留词距) [EN]"; Tag = "EN" },
    @{ Label = "日语 [JAPAN]"; Tag = "JAPAN" },
    @{ Label = "韩语 [KOREAN]"; Tag = "KOREAN" },
    @{ Label = "俄语 [CYRILLIC]"; Tag = "CYRILLIC" }
)

$script:SupportedAllExts  = @('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.gif', '.webp', '.pdf')
$script:CurrentImagePath  = $null
$script:CurrentSourceFile = $null
$script:LastTableGrid     = $null
$script:TempFiles         = New-Object System.Collections.Generic.List[string]
$script:IsDraggingCrop    = $false
$script:CropStartPoint    = $null
$script:CancelRequested   = $false
$script:SyncingTradUI     = $false

function Test-ProEngineReady {
    return (Test-Path $script:ProVenvPy) -and (Test-Path $script:ProWorker)
}

function Get-FriendlyLangLabel {
    param($LangObj)
    $tag = $LangObj.LanguageTag
    if ($script:FriendlyLangMap.ContainsKey($tag)) {
        return "$($script:FriendlyLangMap[$tag]) [$tag]"
    }
    return "$($LangObj.DisplayName) [$tag]"
}

function Parse-PageRange {
    param([string]$RangeText, [int]$TotalPages)
    $pages = New-Object System.Collections.Generic.List[int]
    if ([string]::IsNullOrWhiteSpace($RangeText)) {
        for ($i = 1; $i -le $TotalPages; $i++) { $pages.Add($i) }
        return $pages
    }
    $clean = $RangeText.Replace("，", ",").Replace("－", "-").Replace("—", "-")
    $seen = @{}
    foreach ($part in ($clean -split ",")) {
        $p = $part.Trim()
        if ($p -match '^(\d+)\s*-\s*(\d+)$') {
            $a = [int]$matches[1]; $b = [int]$matches[2]
            if ($a -gt $b) { $tmp = $a; $a = $b; $b = $tmp }
            for ($k = $a; $k -le $b; $k++) {
                if ($k -ge 1 -and $k -le $TotalPages -and -not $seen.ContainsKey($k)) {
                    $seen[$k] = $true; $pages.Add($k)
                }
            }
        } elseif ($p -match '^(\d+)$') {
            $k = [int]$matches[1]
            if ($k -ge 1 -and $k -le $TotalPages -and -not $seen.ContainsKey($k)) {
                $seen[$k] = $true; $pages.Add($k)
            }
        }
    }
    return $pages
}

function Render-PdfPageToPng {
    param($PdfDoc, [uint32]$ZeroBasedPageIndex)
    $page = $null
    $outStream = $null
    try {
        $page = $PdfDoc.GetPage($ZeroBasedPageIndex)
        $tempFolder = Await-WinRT ([Windows.Storage.StorageFolder]::GetFolderFromPathAsync($env:TEMP)) ([Windows.Storage.StorageFolder])
        $fileName = "LocalOCR_pdf_p$($ZeroBasedPageIndex + 1)_" + [Guid]::NewGuid().ToString("N") + ".png"
        $outFile = Await-WinRT ($tempFolder.CreateFileAsync($fileName, [Windows.Storage.CreationCollisionOption]::ReplaceExisting)) ([Windows.Storage.StorageFile])
        $outStream = Await-WinRT ($outFile.OpenAsync([Windows.Storage.FileAccessMode]::ReadWrite)) ([Windows.Storage.Streams.IRandomAccessStream])

        $opts = New-Object Windows.Data.Pdf.PdfPageRenderOptions
        $pageW = [double]$page.Size.Width
        $opts.DestinationWidth = [uint32][Math]::Min(2400, [Math]::Max(1600, [Math]::Round($pageW * 2.2)))

        Await-WinRTAction ($page.RenderToStreamAsync($outStream, $opts))
        return $outFile.Path
    } finally {
        if ($null -ne $outStream) { $outStream.Dispose() }
        if ($null -ne $page) { $page.Dispose() }
    }
}

function Invoke-WinRTOcrBoxes {
    param([string]$FilePath, [string]$LanguageTag)
    $fullPath = [System.IO.Path]::GetFullPath($FilePath)
    $lang = [Windows.Globalization.Language]::new($LanguageTag)
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
    if ($null -eq $engine) {
        throw "无法创建语言 [$LanguageTag] 的 Windows OCR 引擎。请点击「装系统语言包」安装该语言。"
    }
    $stream = $null
    $bitmap = $null
    try {
        $storageFile = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($fullPath)) ([Windows.Storage.StorageFile])
        $stream = Await-WinRT ($storageFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $ocrResult = Await-WinRT ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

        $wordList = New-Object 'System.Collections.Generic.List[OcrWordBox]'
        foreach ($line in $ocrResult.Lines) {
            foreach ($w in $line.Words) {
                $box = New-Object OcrWordBox
                $box.Text = $w.Text
                $box.X = [double]$w.BoundingRect.X
                $box.Y = [double]$w.BoundingRect.Y
                $box.Width = [double]$w.BoundingRect.Width
                $box.Height = [double]$w.BoundingRect.Height
                $wordList.Add($box)
            }
        }
        return @{ Words = $wordList; RawLines = $ocrResult.Lines }
    } finally {
        if ($null -ne $bitmap) { $bitmap.Dispose() }
        if ($null -ne $stream) { $stream.Dispose() }
    }
}

function Invoke-ProRapidOcrBoxes {
    param([string]$FilePath, [string]$LangCode)
    if (-not (Test-ProEngineReady)) {
        throw "专业引擎 (RapidOCR) 尚未安装。请点击右上角「安装专业引擎」完成一次性部署。"
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:ProVenvPy
    $psi.Arguments = "`"$($script:ProWorker)`" --image `"$FilePath`" --lang `"$LangCode`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    [void]$proc.Start()
    $stdout = $proc.StandardOutput.ReadToEnd()
    $stderr = $proc.StandardError.ReadToEnd()
    $proc.WaitForExit()

    $jsonLine = ($stdout -split "`r?`n" | Where-Object { $_.Trim().StartsWith("{") } | Select-Object -Last 1)
    if (-not $jsonLine) {
        throw "专业引擎返回异常：$stderr"
    }
    $parsed = $jsonLine | ConvertFrom-Json
    if (-not $parsed.ok) {
        throw "专业引擎识别失败：$($parsed.error)"
    }
    $wordList = New-Object 'System.Collections.Generic.List[OcrWordBox]'
    foreach ($b in $parsed.boxes) {
        $box = New-Object OcrWordBox
        $box.Text = [string]$b.text
        $box.X = [double]$b.x
        $box.Y = [double]$b.y
        $box.Width = [double]$b.width
        $box.Height = [double]$b.height
        $wordList.Add($box)
    }
    return $wordList
}

function Invoke-OcrOnImageFile {
    param(
        [string]$FilePath,
        [string]$EngineTag,
        [string]$LanguageTag,
        [string]$ModeTag,
        [string]$OrientationTag,
        [string]$TableFormat,
        [bool]$NormalizeBg,
        [bool]$UpscaleSmall,
        [bool]$StripCjkSpaces
    )
    $maxDim = if ($EngineTag -eq "Pro") { 3800 } else { [int][Windows.Media.Ocr.OcrEngine]::MaxImageDimension }
    $targetPath = [System.IO.Path]::GetFullPath($FilePath)
    $tmpPrepPath = $null

    try {
        if ($NormalizeBg -or $UpscaleSmall) {
            $tmpPrepPath = Join-Path $env:TEMP ("LocalOCR_prep_" + [Guid]::NewGuid().ToString("N") + ".png")
            $prep = [LocalOcrTableHelper]::PreprocessImage($targetPath, $tmpPrepPath, $UpscaleSmall, $NormalizeBg, $maxDim)
            $targetPath = $prep.ProcessedImagePath
        }

        $engineLabel = if ($EngineTag -eq "Pro") { "专业引擎(RapidOCR)" } else { "Windows 原生引擎" }
        $wordList = $null
        $rawWinLines = $null

        if ($EngineTag -eq "Pro") {
            $wordList = Invoke-ProRapidOcrBoxes -FilePath $targetPath -LangCode $LanguageTag
        } else {
            $winRes = Invoke-WinRTOcrBoxes -FilePath $targetPath -LanguageTag $LanguageTag
            $wordList = $winRes.Words
            $rawWinLines = $winRes.RawLines
        }

        # 独立竖排模式（右→左台版书 / 左→右竖排）
        if ($OrientationTag -eq "VerticalRL" -or $OrientationTag -eq "VerticalLR") {
            $rtl = ($OrientationTag -eq "VerticalRL")
            $vRes = [LocalOcrTableHelper]::ReconstructVerticalText($wordList, $rtl, $StripCjkSpaces)
            return @{
                Text = $vRes.FormattedText
                Grid = $null
                Info = "$engineLabel · $($vRes.SummaryInfo)"
            }
        }

        # 横排：普通纯文本模式
        if ($ModeTag -eq "Plain") {
            if ($EngineTag -eq "WinRT" -and $null -ne $rawWinLines) {
                $lines = New-Object System.Collections.Generic.List[string]
                foreach ($line in $rawWinLines) {
                    $t = $line.Text
                    if ($StripCjkSpaces) { $t = [LocalOcrTableHelper]::CleanCjkSpaces($t) }
                    $lines.Add($t)
                }
                return @{ Text = ($lines -join "`r`n"); Grid = $null; Info = "$engineLabel · 普通文本" }
            }
            $layoutPlain = [LocalOcrTableHelper]::ReconstructLayout($wordList, $false, "TSV", $StripCjkSpaces)
            return @{ Text = $layoutPlain.FormattedText; Grid = $null; Info = "$engineLabel · 普通文本" }
        }

        # 横排：图文分区 / 纯表格模式
        $forceTable = ($ModeTag -eq "TableOnly")
        $layoutRes = [LocalOcrTableHelper]::ReconstructLayout($wordList, $forceTable, $TableFormat, $StripCjkSpaces)
        return @{
            Text = $layoutRes.FormattedText
            Grid = $layoutRes.PrimaryTableGrid
            Info = "$engineLabel · $($layoutRes.SummaryInfo)"
        }
    } finally {
        if ($tmpPrepPath -and (Test-Path $tmpPrepPath)) {
            Remove-Item $tmpPrepPath -Force -ErrorAction SilentlyContinue
        }
    }
}

# WPF XAML 界面定义
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="LocalOCR v6.0 - 纯离线双引擎 OCR（竖排台版书 + 繁体字 + 影印PDF + 表格）"
        Width="1260" Height="780" MinWidth="1020" MinHeight="600"
        WindowStartupLocation="CenterScreen"
        Background="#F4F6F9"
        FontFamily="Microsoft YaHei UI, Segoe UI"
        AllowDrop="True">
    <Window.Resources>
        <Style x:Key="PrimaryBtn" TargetType="Button">
            <Setter Property="Background" Value="#2563EB"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="12,7"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#1D4ED8"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="ProBtn" TargetType="Button">
            <Setter Property="Background" Value="#7C3AED"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="10,5"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#6D28D9"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="DangerBtn" TargetType="Button">
            <Setter Property="Background" Value="#DC2626"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="10,7"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#B91C1C"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="ExcelBtn" TargetType="Button">
            <Setter Property="Background" Value="#0F766E"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="10,5"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#115E59"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="SecondaryBtn" TargetType="Button">
            <Setter Property="Background" Value="White"/>
            <Setter Property="Foreground" Value="#1E293B"/>
            <Setter Property="Padding" Value="10,7"/>
            <Setter Property="BorderBrush" Value="#CBD5E1"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#F1F5F9"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Grid Margin="14">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- 第一行：文件/PDF 操作 + 引擎与语言切换 -->
        <Border Grid.Row="0" Background="White" CornerRadius="8" Padding="12,10" BorderBrush="#E2E8F0" BorderThickness="1">
            <DockPanel LastChildFill="False">
                <StackPanel Orientation="Horizontal" DockPanel.Dock="Left" VerticalAlignment="Center">
                    <Button x:Name="BtnSelectFiles" Content="选择图片 / PDF" Style="{StaticResource PrimaryBtn}" Margin="0,0,7,0"/>
                    <Button x:Name="BtnPaste" Content="粘贴截图 (Ctrl+V)" Style="{StaticResource SecondaryBtn}" Margin="0,0,7,0"/>
                    <Button x:Name="BtnBatchFolder" Content="批量文件夹" Style="{StaticResource SecondaryBtn}" Margin="0,0,7,0"/>
                    <Button x:Name="BtnReRecognize" Content="重新识别" Style="{StaticResource SecondaryBtn}" Margin="0,0,7,0"/>
                    <Button x:Name="BtnStop" Content="停止" Style="{StaticResource DangerBtn}" Visibility="Collapsed"/>
                </StackPanel>

                <StackPanel Orientation="Horizontal" DockPanel.Dock="Right" VerticalAlignment="Center">
                    <TextBlock Text="引擎：" VerticalAlignment="Center" Foreground="#334155" FontWeight="SemiBold" Margin="0,0,4,0"/>
                    <ComboBox x:Name="CmbEngine" Width="185" Height="30" VerticalContentAlignment="Center" Margin="0,0,8,0">
                        <ComboBoxItem x:Name="ItemWinEngine" Content="Windows 原生 (免装)" Tag="WinRT" IsSelected="True"/>
                        <ComboBoxItem x:Name="ItemProEngine" Content="专业引擎 RapidOCR" Tag="Pro"/>
                    </ComboBox>

                    <TextBlock Text="语言：" VerticalAlignment="Center" Foreground="#475569" Margin="0,0,4,0"/>
                    <ComboBox x:Name="CmbLanguage" Width="195" Height="30" VerticalContentAlignment="Center" Margin="0,0,6,0"/>
                    <Button x:Name="BtnRefreshLang" Content="刷新" Style="{StaticResource SecondaryBtn}" Padding="8,5" Margin="0,0,6,0"/>
                    <Button x:Name="BtnInstallPro" Content="安装专业引擎" Style="{StaticResource ProBtn}" Margin="0,0,6,0"/>
                    <Button x:Name="BtnInstallLang" Content="装系统语言包" Style="{StaticResource SecondaryBtn}" Padding="8,5"/>
                </StackPanel>
            </DockPanel>
        </Border>

        <!-- 第二行：竖排选项 + 繁体字独立选项 + PDF页码 + 表格与图像增强 -->
        <Border Grid.Row="1" Background="#F8FAFC" CornerRadius="8" Padding="12,8" Margin="0,8,0,8" BorderBrush="#E2E8F0" BorderThickness="1">
            <DockPanel LastChildFill="False">
                <StackPanel Orientation="Horizontal" DockPanel.Dock="Left" VerticalAlignment="Center">
                    <!-- 独立选项 1：竖排 / 横排方向 -->
                    <TextBlock Text="排版：" VerticalAlignment="Center" Foreground="#1D4ED8" FontWeight="Bold" Margin="0,0,4,0"/>
                    <ComboBox x:Name="CmbOrientation" Width="155" Height="28" VerticalContentAlignment="Center" Margin="0,0,10,0" ToolTip="台版书籍/古籍请选择「竖排 (右→左·台版)」">
                        <ComboBoxItem Content="横排 (默认)" Tag="Horizontal" IsSelected="True"/>
                        <ComboBoxItem Content="竖排 (右→左·台版)" Tag="VerticalRL"/>
                        <ComboBoxItem Content="竖排 (左→右)" Tag="VerticalLR"/>
                    </ComboBox>

                    <!-- 独立选项 2：繁体字识别开关 -->
                    <CheckBox x:Name="ChkTraditional" Content="繁体字识别" IsChecked="False" VerticalAlignment="Center" Foreground="#7C3AED" FontWeight="Bold" Margin="0,0,12,0" ToolTip="独立开关：勾选后自动切换为繁体中文识别模型（支持与横排或竖排自由组合）"/>

                    <TextBlock Text="PDF页码：" VerticalAlignment="Center" Foreground="#334155" Margin="0,0,4,0"/>
                    <TextBox x:Name="TxtPdfPages" Width="76" Height="26" VerticalContentAlignment="Center" Padding="4,0" Margin="0,0,10,0" ToolTip="留空为全部页；可填如 1-5 或 1,3,8-10"/>

                    <ComboBox x:Name="CmbMode" Width="145" Height="28" VerticalContentAlignment="Center" Margin="0,0,6,0">
                        <ComboBoxItem Content="图文+表格分区" Tag="Mixed" IsSelected="True"/>
                        <ComboBoxItem Content="纯表格模式" Tag="TableOnly"/>
                        <ComboBoxItem Content="普通纯文本" Tag="Plain"/>
                    </ComboBox>

                    <ComboBox x:Name="CmbTableFormat" Width="125" Height="28" VerticalContentAlignment="Center" Margin="0,0,8,0">
                        <ComboBoxItem Content="TSV (Excel)" Tag="TSV" IsSelected="True"/>
                        <ComboBoxItem Content="Markdown表" Tag="Markdown"/>
                        <ComboBoxItem Content="对齐纯文本" Tag="Aligned"/>
                    </ComboBox>

                    <CheckBox x:Name="ChkNormalizeBg" Content="去底色" IsChecked="True" VerticalAlignment="Center" Foreground="#334155" Margin="0,0,7,0"/>
                    <CheckBox x:Name="ChkUpscale" Content="放大" IsChecked="True" VerticalAlignment="Center" Foreground="#334155" Margin="0,0,7,0"/>
                    <CheckBox x:Name="ChkStripCjkSpace" Content="去中空" IsChecked="True" VerticalAlignment="Center" Foreground="#334155"/>
                </StackPanel>

                <StackPanel Orientation="Horizontal" DockPanel.Dock="Right" VerticalAlignment="Center">
                    <Button x:Name="BtnCopy" Content="复制" Style="{StaticResource SecondaryBtn}" Padding="9,5" Margin="0,0,5,0"/>
                    <Button x:Name="BtnExportCsv" Content="导出 CSV" Style="{StaticResource ExcelBtn}" Margin="0,0,5,0"/>
                    <Button x:Name="BtnExportTxt" Content="导出 TXT" Style="{StaticResource SecondaryBtn}" Padding="9,5" Margin="0,0,5,0"/>
                    <Button x:Name="BtnClear" Content="清空" Style="{StaticResource SecondaryBtn}" Padding="9,5"/>
                </StackPanel>
            </DockPanel>
        </Border>

        <!-- 主体左右分栏 -->
        <Grid Grid.Row="2">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="42*" MinWidth="280"/>
                <ColumnDefinition Width="10"/>
                <ColumnDefinition Width="58*" MinWidth="360"/>
            </Grid.ColumnDefinitions>

            <Border Grid.Column="0" Background="White" CornerRadius="8" BorderBrush="#E2E8F0" BorderThickness="1" Padding="10">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>
                    <TextBlock x:Name="TxtImageHeader" Text="图片 / PDF 页面预览（可按左键直接框选区域识别）" Foreground="#475569" FontWeight="SemiBold" Margin="0,0,0,8"/>
                    <Border Grid.Row="1" Background="#F8FAFC" CornerRadius="6" BorderBrush="#E2E8F0" BorderThickness="1" ClipToBounds="True">
                        <Grid>
                            <TextBlock x:Name="TxtPlaceholder" Text="拖入图片或影印版 PDF 文件&#10;或用 Win+Shift+S 截图后按 Ctrl+V&#10;&#10;台版竖排书籍：选择「竖排 (右→左·台版)」并勾选「繁体字识别」"
                                       Foreground="#94A3B8" FontSize="13.5" TextAlignment="Center"
                                       HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            <Grid HorizontalAlignment="Center" VerticalAlignment="Center">
                                <Image x:Name="ImgPreview" Stretch="Uniform" Cursor="Cross"/>
                                <Canvas x:Name="CropCanvas" IsHitTestVisible="False">
                                    <Rectangle x:Name="CropRect" Stroke="#2563EB" StrokeThickness="2" StrokeDashArray="4 2" Fill="#222563EB" Visibility="Collapsed"/>
                                </Canvas>
                            </Grid>
                        </Grid>
                    </Border>
                </Grid>
            </Border>

            <GridSplitter Grid.Column="1" Width="10" HorizontalAlignment="Stretch" Background="Transparent"/>

            <Border Grid.Column="2" Background="White" CornerRadius="8" BorderBrush="#E2E8F0" BorderThickness="1" Padding="10">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>
                    <DockPanel Grid.Row="0" Margin="0,0,0,8">
                        <TextBlock x:Name="TxtResultHeader" Text="识别结果（支持横排/竖排自动排序、繁体识别、表格对齐与 PDF 分页）" Foreground="#475569" FontWeight="SemiBold" DockPanel.Dock="Left"/>
                        <TextBlock x:Name="TxtCharCount" Text="0 字符" Foreground="#94A3B8" DockPanel.Dock="Right" FontSize="12"/>
                    </DockPanel>
                    <TextBox x:Name="TxtResult" Grid.Row="1"
                             AcceptsReturn="True" AcceptsTab="True"
                             TextWrapping="NoWrap"
                             VerticalScrollBarVisibility="Auto"
                             HorizontalScrollBarVisibility="Auto"
                             FontFamily="Consolas, Microsoft YaHei UI"
                             FontSize="13.5" Padding="10"
                             BorderBrush="#E2E8F0" BorderThickness="1"
                             Background="#FCFDFE" Foreground="#0F172A"/>
                </Grid>
            </Border>
        </Grid>

        <!-- 底部状态栏 -->
        <Border Grid.Row="3" Background="#EEF2F6" CornerRadius="6" Padding="10,6" Margin="0,10,0,0">
            <DockPanel>
                <TextBlock x:Name="TxtStatus" Text="就绪 - 已将「排版方向(竖排)」与「繁体字识别」设为两个独立选项，可按需自由组合。" Foreground="#475569" FontSize="12" DockPanel.Dock="Left"/>
                <TextBlock x:Name="TxtEngineStatus" Text="" Foreground="#64748B" FontSize="12" DockPanel.Dock="Right"/>
            </DockPanel>
        </Border>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

$btnSelectFiles = $window.FindName("BtnSelectFiles")
$btnPaste       = $window.FindName("BtnPaste")
$btnBatchFolder = $window.FindName("BtnBatchFolder")
$btnReRecognize = $window.FindName("BtnReRecognize")
$btnStop        = $window.FindName("BtnStop")
$cmbEngine      = $window.FindName("CmbEngine")
$itemProEngine  = $window.FindName("ItemProEngine")
$cmbLanguage    = $window.FindName("CmbLanguage")
$btnRefreshLang = $window.FindName("BtnRefreshLang")
$btnInstallPro  = $window.FindName("BtnInstallPro")
$btnInstallLang = $window.FindName("BtnInstallLang")
$cmbOrientation = $window.FindName("CmbOrientation")
$chkTraditional = $window.FindName("ChkTraditional")
$txtPdfPages    = $window.FindName("TxtPdfPages")
$cmbMode        = $window.FindName("CmbMode")
$cmbTableFormat = $window.FindName("CmbTableFormat")
$chkNormalizeBg = $window.FindName("ChkNormalizeBg")
$chkUpscale     = $window.FindName("ChkUpscale")
$chkStripCjk    = $window.FindName("ChkStripCjkSpace")
$btnCopy        = $window.FindName("BtnCopy")
$btnExportCsv   = $window.FindName("BtnExportCsv")
$btnExportTxt   = $window.FindName("BtnExportTxt")
$btnClear       = $window.FindName("BtnClear")
$txtImageHeader = $window.FindName("TxtImageHeader")
$txtPlaceholder = $window.FindName("TxtPlaceholder")
$imgPreview     = $window.FindName("ImgPreview")
$cropCanvas     = $window.FindName("CropCanvas")
$cropRect       = $window.FindName("CropRect")
$txtResultHeader= $window.FindName("TxtResultHeader")
$txtResult      = $window.FindName("TxtResult")
$txtCharCount   = $window.FindName("TxtCharCount")
$txtStatus      = $window.FindName("TxtStatus")
$txtEngineStatus= $window.FindName("TxtEngineStatus")

function Update-CharCount {
    $len = if ($null -ne $txtResult.Text) { $txtResult.Text.Length } else { 0 }
    $txtCharCount.Text = "$len 字符"
}

function Update-EngineStatusUI {
    if (Test-ProEngineReady) {
        $itemProEngine.Content = "专业引擎 RapidOCR (已就绪)"
        $btnInstallPro.Content = "更新专业引擎"
        $txtEngineStatus.Text = "专业引擎(RapidOCR)：已安装 · 可离线"
    } else {
        $itemProEngine.Content = "专业引擎 RapidOCR (未安装)"
        $btnInstallPro.Content = "安装专业引擎"
        $txtEngineStatus.Text = "专业引擎(RapidOCR)：未安装（点右上角紫色按钮部署）"
    }
}

function Update-ModeUI {
    $oriTag = if ($cmbOrientation.SelectedItem) { $cmbOrientation.SelectedItem.Tag } else { "Horizontal" }
    $isVert = ($oriTag -eq "VerticalRL" -or $oriTag -eq "VerticalLR")
    $cmbMode.IsEnabled = (-not $isVert)
    $modeTag = if ($cmbMode.SelectedItem) { $cmbMode.SelectedItem.Tag } else { "Mixed" }
    $cmbTableFormat.IsEnabled = ((-not $isVert) -and ($modeTag -ne "Plain"))

    if ($isVert) {
        $txtResult.TextWrapping = [System.Windows.TextWrapping]::Wrap
        $dirText = if ($oriTag -eq "VerticalRL") { "从右到左·台版/古籍" } else { "从左到右" }
        $txtResultHeader.Text = "识别结果（竖排模式：$dirText，每列按从上到下排序输出）"
    } elseif ($modeTag -eq "Plain") {
        $txtResult.TextWrapping = [System.Windows.TextWrapping]::Wrap
        $txtResultHeader.Text = "识别结果（普通纯文本模式，可直接编辑）"
    } elseif ($modeTag -eq "TableOnly") {
        $txtResult.TextWrapping = [System.Windows.TextWrapping]::NoWrap
        $txtResultHeader.Text = "识别结果（纯表格模式，TSV 复制后可直接粘贴 Excel 自动分列）"
    } else {
        $txtResult.TextWrapping = [System.Windows.TextWrapping]::NoWrap
        $txtResultHeader.Text = "识别结果（正文正常排版，表格按列对齐，多页 PDF 自动分页）"
    }
}

function Apply-TraditionalToggle {
    param([bool]$WantTraditional)
    if ($script:SyncingTradUI) { return }
    $script:SyncingTradUI = $true
    try {
        $engineTag = if ($cmbEngine.SelectedItem) { $cmbEngine.SelectedItem.Tag } else { "WinRT" }
        if ($WantTraditional) {
            if ($engineTag -eq "Pro") {
                for ($i = 0; $i -lt $cmbLanguage.Items.Count; $i++) {
                    if ($cmbLanguage.Items[$i].Tag -eq "CHINESE_CHT") {
                        $cmbLanguage.SelectedIndex = $i
                        $txtStatus.Text = "已开启「繁体字识别」：当前使用 RapidOCR 繁体中文模型 [CHINESE_CHT]。"
                        return
                    }
                }
            } else {
                for ($i = 0; $i -lt $cmbLanguage.Items.Count; $i++) {
                    $t = $cmbLanguage.Items[$i].Tag
                    if ($t -like "zh-Hant*" -or $t -eq "zh-TW" -or $t -eq "zh-HK") {
                        $cmbLanguage.SelectedIndex = $i
                        $txtStatus.Text = "已开启「繁体字识别」：当前使用 Windows 原生繁体包 [$t]。"
                        return
                    }
                }
                $chkTraditional.IsChecked = $false
                $ask = [System.Windows.MessageBox]::Show(
                    "当前系统尚未安装 Windows 繁体中文 OCR 语言包 (zh-TW / zh-HK)。`r`n是否现在运行语言包安装助手进行安装？（装完后点「刷新」即可离线使用）",
                    "未检测到繁体语言包",
                    [System.Windows.MessageBoxButton]::YesNo,
                    [System.Windows.MessageBoxImage]::Information
                )
                if ($ask -eq [System.Windows.MessageBoxResult]::Yes) {
                    $installer = Join-Path $script:AppDir "InstallLanguages.ps1"
                    if (Test-Path $installer) {
                        Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$installer`""
                    }
                }
            }
        } else {
            # 取消勾选繁体字时，若当前正好是繁体，则切回简体中文
            $curTag = if ($cmbLanguage.SelectedItem) { $cmbLanguage.SelectedItem.Tag } else { "" }
            if ($engineTag -eq "Pro" -and $curTag -eq "CHINESE_CHT") {
                $cmbLanguage.SelectedIndex = 0
                $txtStatus.Text = "已关闭「繁体字识别」，切换回中英/简体模型 [CH]。"
            } elseif ($engineTag -eq "WinRT" -and ($curTag -like "zh-Hant*" -or $curTag -eq "zh-TW" -or $curTag -eq "zh-HK")) {
                for ($i = 0; $i -lt $cmbLanguage.Items.Count; $i++) {
                    $t = $cmbLanguage.Items[$i].Tag
                    if ($t -like "zh-Hans*" -or $t -eq "zh-CN") {
                        $cmbLanguage.SelectedIndex = $i
                        $txtStatus.Text = "已关闭「繁体字识别」，切换回简体中文 [$t]。"
                        break
                    }
                }
            }
        }
    } finally {
        $script:SyncingTradUI = $false
    }
}

function Load-LanguagesForCurrentEngine {
    $script:SyncingTradUI = $true
    try {
        $engineTag = if ($cmbEngine.SelectedItem) { $cmbEngine.SelectedItem.Tag } else { "WinRT" }
        $wantTrad = [bool]$chkTraditional.IsChecked
        $cmbLanguage.Items.Clear()

        if ($engineTag -eq "Pro") {
            foreach ($p in $script:ProLanguageList) {
                $item = New-Object System.Windows.Controls.ComboBoxItem
                $item.Content = $p.Label
                $item.Tag = $p.Tag
                $cmbLanguage.Items.Add($item) | Out-Null
            }
            $cmbLanguage.SelectedIndex = if ($wantTrad) { 1 } else { 0 }
            if (-not (Test-ProEngineReady)) {
                $txtStatus.Text = "提示：专业引擎尚未安装，请点击右上角「安装专业引擎」（装完后永久离线）。"
            }
            return
        }

        $langs = [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages
        foreach ($l in $langs) {
            $item = New-Object System.Windows.Controls.ComboBoxItem
            $item.Content = Get-FriendlyLangLabel $l
            $item.Tag = $l.LanguageTag
            $cmbLanguage.Items.Add($item) | Out-Null
        }
        if ($cmbLanguage.Items.Count -eq 0) {
            $txtStatus.Text = "未检测到 Windows OCR 语言包，请点击「装系统语言包」或安装「专业引擎」。"
            return
        }
        $selectedIndex = 0
        for ($i = 0; $i -lt $cmbLanguage.Items.Count; $i++) {
            $t = $cmbLanguage.Items[$i].Tag
            if ($wantTrad -and ($t -like "zh-Hant*" -or $t -eq "zh-TW" -or $t -eq "zh-HK")) {
                $selectedIndex = $i; break
            }
            if (-not $wantTrad -and ($t -like "zh-Hans*" -or $t -eq "zh-CN")) {
                $selectedIndex = $i; break
            }
        }
        $cmbLanguage.SelectedIndex = $selectedIndex
    } finally {
        $script:SyncingTradUI = $false
    }
}

function Show-PreviewImage {
    param([string]$FilePath, [string]$CustomHeader = $null)
    $cropRect.Visibility = [System.Windows.Visibility]::Collapsed
    try {
        $bmp = New-Object System.Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit()
        $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bmp.UriSource = New-Object System.Uri([System.IO.Path]::GetFullPath($FilePath))
        $bmp.EndInit()
        $bmp.Freeze()
        $imgPreview.Source = $bmp
        $txtPlaceholder.Visibility = [System.Windows.Visibility]::Collapsed
        if ($CustomHeader) {
            $txtImageHeader.Text = $CustomHeader
        } else {
            $txtImageHeader.Text = "预览：$([System.IO.Path]::GetFileName($FilePath))（可左键框选区域）"
        }
    } catch {
        $imgPreview.Source = $null
        $txtPlaceholder.Visibility = [System.Windows.Visibility]::Visible
    }
}

function Start-ProEngineInstaller {
    $installer = Join-Path $script:AppDir "InstallProEngine.ps1"
    if (Test-Path $installer) {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$installer`""
    }
}

function Process-InputFiles {
    param([string[]]$Paths, [string]$OverrideMode = $null, [bool]$SkipPreview = $false)
    if ($null -eq $Paths -or $Paths.Count -eq 0) { return }
    $engineTag = if ($cmbEngine.SelectedItem) { $cmbEngine.SelectedItem.Tag } else { "WinRT" }

    if ($engineTag -eq "Pro" -and -not (Test-ProEngineReady)) {
        $ask = [System.Windows.MessageBox]::Show(
            "专业离线引擎 (RapidOCR) 尚未安装。是否现在启动一键安装助手？`r`n（仅首次安装需临时联网，装完后即可完全断网使用）",
            "安装专业引擎",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Question
        )
        if ($ask -eq [System.Windows.MessageBoxResult]::Yes) { Start-ProEngineInstaller }
        return
    }
    if ($null -eq $cmbLanguage.SelectedItem) {
        [System.Windows.MessageBox]::Show("当前没有可用的 OCR 语言选项。", "提示") | Out-Null
        return
    }

    $langTag = $cmbLanguage.SelectedItem.Tag
    $oriTag  = if ($cmbOrientation.SelectedItem) { $cmbOrientation.SelectedItem.Tag } else { "Horizontal" }
    $modeTag = if ($OverrideMode) { $OverrideMode } elseif ($cmbMode.SelectedItem) { $cmbMode.SelectedItem.Tag } else { "Mixed" }
    $tableFmt = if ($cmbTableFormat.SelectedItem) { $cmbTableFormat.SelectedItem.Tag } else { "TSV" }
    $normBg = [bool]$chkNormalizeBg.IsChecked
    $upscale = [bool]$chkUpscale.IsChecked
    $stripCjk = [bool]$chkStripCjk.IsChecked

    $validFiles = @($Paths | Where-Object {
        (Test-Path $_ -PathType Leaf) -and ($script:SupportedAllExts -contains ([System.IO.Path]::GetExtension($_).ToLowerInvariant()))
    })
    if ($validFiles.Count -eq 0) {
        $txtStatus.Text = "未找到支持的图片或 PDF 文件。"
        return
    }

    if (-not $SkipPreview) {
        $script:CurrentSourceFile = $validFiles[0]
    }
    $script:LastTableGrid = $null
    $script:CancelRequested = $false
    $btnStop.Visibility = [System.Windows.Visibility]::Visible

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $outputBuilder = New-Object System.Text.StringBuilder
    $processedPages = 0
    $lastInfo = ""

    try {
        for ($i = 0; $i -lt $validFiles.Count; $i++) {
            if ($script:CancelRequested) { break }
            $f = $validFiles[$i]
            $ext = [System.IO.Path]::GetExtension($f).ToLowerInvariant()
            $fname = [System.IO.Path]::GetFileName($f)

            if ($ext -eq ".pdf") {
                $txtStatus.Text = "正在加载影印 PDF：$fname ..."
                [System.Windows.Forms.Application]::DoEvents()
                try {
                    $pdfStorageFile = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync([System.IO.Path]::GetFullPath($f))) ([Windows.Storage.StorageFile])
                    $pdfDoc = Await-WinRT ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($pdfStorageFile)) ([Windows.Data.Pdf.PdfDocument])
                    if ($pdfDoc.IsPasswordProtected) {
                        [void]$outputBuilder.AppendLine("[跳过加密 PDF: $fname] 该 PDF 受密码保护，请先解除密码。")
                        continue
                    }
                    $totalPages = [int]$pdfDoc.PageCount
                    $targetPages = Parse-PageRange -RangeText $txtPdfPages.Text -TotalPages $totalPages
                    if ($targetPages.Count -eq 0) {
                        [void]$outputBuilder.AppendLine("[提示: $fname] 页码范围 '$($txtPdfPages.Text)' 超出总页数 ($totalPages)。")
                        continue
                    }

                    if ($validFiles.Count -gt 1) {
                        [void]$outputBuilder.AppendLine("########## PDF: $fname (共 $totalPages 页) ##########")
                    }

                    for ($pi = 0; $pi -lt $targetPages.Count; $pi++) {
                        if ($script:CancelRequested) { break }
                        $pageNum = $targetPages[$pi]
                        $txtStatus.Text = "正在渲染并离线识别 PDF [$fname]：第 $pageNum 页（进度 $($pi + 1)/$($targetPages.Count)）..."
                        [System.Windows.Forms.Application]::DoEvents()

                        $renderedPng = Render-PdfPageToPng -PdfDoc $pdfDoc -ZeroBasedPageIndex ([uint32]($pageNum - 1))
                        $script:TempFiles.Add($renderedPng)
                        $script:CurrentImagePath = $renderedPng
                        Show-PreviewImage -FilePath $renderedPng -CustomHeader "PDF 预览：$fname - 第 $pageNum/$totalPages 页（可左键框选）"
                        [System.Windows.Forms.Application]::DoEvents()

                        $res = Invoke-OcrOnImageFile -FilePath $renderedPng -EngineTag $engineTag -LanguageTag $langTag -ModeTag $modeTag -OrientationTag $oriTag -TableFormat $tableFmt -NormalizeBg $normBg -UpscaleSmall $false -StripCjkSpaces $stripCjk
                        [void]$outputBuilder.AppendLine("===== 第 $pageNum 页 =====")
                        [void]$outputBuilder.AppendLine($res.Text)
                        [void]$outputBuilder.AppendLine("")

                        if ($null -ne $res.Grid -and $res.Grid.Count -gt 0) { $script:LastTableGrid = $res.Grid }
                        $lastInfo = $res.Info
                        $processedPages++
                        $txtResult.Text = $outputBuilder.ToString().TrimEnd()
                        Update-CharCount
                        [System.Windows.Forms.Application]::DoEvents()
                    }
                } catch {
                    [void]$outputBuilder.AppendLine("[PDF 处理失败: $fname] $($_.Exception.Message)")
                }
            } else {
                if (-not $SkipPreview) {
                    $script:CurrentImagePath = $f
                    Show-PreviewImage $f
                }
                $txtStatus.Text = "正在离线识别 ($($i + 1)/$($validFiles.Count))：$fname ..."
                [System.Windows.Forms.Application]::DoEvents()
                try {
                    $res = Invoke-OcrOnImageFile -FilePath $f -EngineTag $engineTag -LanguageTag $langTag -ModeTag $modeTag -OrientationTag $oriTag -TableFormat $tableFmt -NormalizeBg $normBg -UpscaleSmall $upscale -StripCjkSpaces $stripCjk
                    if ($validFiles.Count -gt 1) {
                        [void]$outputBuilder.AppendLine("===== $fname =====")
                    }
                    [void]$outputBuilder.AppendLine($res.Text)
                    if ($validFiles.Count -gt 1) {
                        [void]$outputBuilder.AppendLine("")
                    }
                    if ($validFiles.Count -eq 1 -and $null -ne $res.Grid) { $script:LastTableGrid = $res.Grid }
                    $lastInfo = $res.Info
                    $processedPages++
                } catch {
                    [void]$outputBuilder.AppendLine("[识别失败: $fname] $($_.Exception.Message)")
                }
            }
        }
    } finally {
        $btnStop.Visibility = [System.Windows.Visibility]::Collapsed
    }

    $sw.Stop()
    $txtResult.Text = $outputBuilder.ToString().TrimEnd()
    Update-CharCount
    $statusPrefix = if ($script:CancelRequested) { "已手动停止（保留已识别的 $processedPages 页/张）" } elseif ($SkipPreview) { "框选区域识别完成" } else { "识别完成（共 $processedPages 页/张）" }
    $txtStatus.Text = "$statusPrefix | $lastInfo | 语言 [$langTag] | 耗时 $([math]::Round($sw.Elapsed.TotalSeconds, 2)) 秒"
}

function Process-ClipboardImage {
    if (-not [System.Windows.Clipboard]::ContainsImage()) {
        $txtStatus.Text = "剪贴板中没有图片。请先使用 Win+Shift+S 或截图工具截图。"
        return
    }
    try {
        $imgSource = [System.Windows.Clipboard]::GetImage()
        $tempPath = Join-Path $env:TEMP ("LocalOCR_clip_" + [Guid]::NewGuid().ToString("N") + ".png")
        $encoder = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
        $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($imgSource))
        $fs = [System.IO.File]::OpenWrite($tempPath)
        try { $encoder.Save($fs) } finally { $fs.Close() }
        $script:TempFiles.Add($tempPath)
        Process-InputFiles @($tempPath)
        $txtImageHeader.Text = "预览：剪贴板截图（可左键框选区域）"
    } catch {
        $txtStatus.Text = "读取剪贴板图片失败：$($_.Exception.Message)"
    }
}

# 左侧预览图：鼠标左键拖动框选区域
$imgPreview.Add_MouseLeftButtonDown({
    param($s, $e)
    if (-not $script:CurrentImagePath -or -not (Test-Path $script:CurrentImagePath)) { return }
    $script:IsDraggingCrop = $true
    $script:CropStartPoint = $e.GetPosition($imgPreview)
    $cropCanvas.Width = $imgPreview.ActualWidth
    $cropCanvas.Height = $imgPreview.ActualHeight
    [System.Windows.Controls.Canvas]::SetLeft($cropRect, $script:CropStartPoint.X)
    [System.Windows.Controls.Canvas]::SetTop($cropRect, $script:CropStartPoint.Y)
    $cropRect.Width = 0
    $cropRect.Height = 0
    $cropRect.Visibility = [System.Windows.Visibility]::Visible
    $imgPreview.CaptureMouse() | Out-Null
})

$imgPreview.Add_MouseMove({
    param($s, $e)
    if (-not $script:IsDraggingCrop) { return }
    $pos = $e.GetPosition($imgPreview)
    $x = [Math]::Max(0, [Math]::Min($pos.X, $imgPreview.ActualWidth))
    $y = [Math]::Max(0, [Math]::Min($pos.Y, $imgPreview.ActualHeight))
    $rx = [Math]::Min($script:CropStartPoint.X, $x)
    $ry = [Math]::Min($script:CropStartPoint.Y, $y)
    $rw = [Math]::Abs($x - $script:CropStartPoint.X)
    $rh = [Math]::Abs($y - $script:CropStartPoint.Y)
    [System.Windows.Controls.Canvas]::SetLeft($cropRect, $rx)
    [System.Windows.Controls.Canvas]::SetTop($cropRect, $ry)
    $cropRect.Width = $rw
    $cropRect.Height = $rh
})

$imgPreview.Add_MouseLeftButtonUp({
    param($s, $e)
    if (-not $script:IsDraggingCrop) { return }
    $script:IsDraggingCrop = $false
    $imgPreview.ReleaseMouseCapture()

    $rw = $cropRect.Width
    $rh = $cropRect.Height
    if ($rw -lt 18 -or $rh -lt 18 -or $imgPreview.ActualWidth -le 0 -or $imgPreview.ActualHeight -le 0) {
        $cropRect.Visibility = [System.Windows.Visibility]::Collapsed
        return
    }

    $rx = [System.Windows.Controls.Canvas]::GetLeft($cropRect)
    $ry = [System.Windows.Controls.Canvas]::GetTop($cropRect)
    try {
        $cropPath = Join-Path $env:TEMP ("LocalOCR_crop_" + [Guid]::NewGuid().ToString("N") + ".png")
        [LocalOcrTableHelper]::CropImageNormalized(
            $script:CurrentImagePath, $cropPath,
            ($rx / $imgPreview.ActualWidth), ($ry / $imgPreview.ActualHeight),
            ($rw / $imgPreview.ActualWidth), ($rh / $imgPreview.ActualHeight)
        ) | Out-Null
        $script:TempFiles.Add($cropPath)
        $oriTag = if ($cmbOrientation.SelectedItem) { $cmbOrientation.SelectedItem.Tag } else { "Horizontal" }
        $override = if ($oriTag -ne "Horizontal") { "Plain" } elseif ($cmbMode.SelectedItem -and $cmbMode.SelectedItem.Tag -eq "Plain") { "Plain" } else { "TableOnly" }
        Process-InputFiles @($cropPath) -OverrideMode $override -SkipPreview $true
    } catch {
        $txtStatus.Text = "框选识别失败：$($_.Exception.Message)"
    }
})

# 事件绑定
$txtResult.Add_TextChanged({ Update-CharCount })
$cmbMode.Add_SelectionChanged({ Update-ModeUI })
$cmbOrientation.Add_SelectionChanged({ Update-ModeUI })

$chkTraditional.Add_Checked({ Apply-TraditionalToggle $true })
$chkTraditional.Add_Unchecked({ Apply-TraditionalToggle $false })

$cmbLanguage.Add_SelectionChanged({
    if ($script:SyncingTradUI) { return }
    $script:SyncingTradUI = $true
    try {
        $t = if ($cmbLanguage.SelectedItem) { $cmbLanguage.SelectedItem.Tag } else { "" }
        $isTradLang = ($t -eq "CHINESE_CHT" -or $t -like "zh-Hant*" -or $t -eq "zh-TW" -or $t -eq "zh-HK")
        $chkTraditional.IsChecked = $isTradLang
    } finally {
        $script:SyncingTradUI = $false
    }
})

$cmbEngine.Add_SelectionChanged({
    Update-EngineStatusUI
    Load-LanguagesForCurrentEngine
})

$cmbTableFormat.Add_SelectionChanged({
    if ($null -ne $script:LastTableGrid -and $cmbMode.SelectedItem -and $cmbMode.SelectedItem.Tag -eq "TableOnly") {
        $fmt = $cmbTableFormat.SelectedItem.Tag
        $txtResult.Text = [LocalOcrTableHelper]::FormatTable($script:LastTableGrid, $fmt)
        Update-CharCount
        $txtStatus.Text = "已切换表格显示格式为：$fmt"
    }
})

$btnSelectFiles.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = "选择图片或影印版 PDF（支持多选）"
    $dlg.Multiselect = $true
    $dlg.Filter = "图片与 PDF|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif;*.webp;*.pdf|PDF 文件 (*.pdf)|*.pdf|图片文件|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif;*.webp|所有文件|*.*"
    if ($dlg.ShowDialog() -eq $true) { Process-InputFiles $dlg.FileNames }
})

$btnPaste.Add_Click({ Process-ClipboardImage })

$btnBatchFolder.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    $fbd.Description = "选择包含图片或影印 PDF 的文件夹进行批量离线识别"
    if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $files = Get-ChildItem -Path $fbd.SelectedPath -File | Where-Object {
            $script:SupportedAllExts -contains $_.Extension.ToLowerInvariant()
        } | Sort-Object Name | ForEach-Object { $_.FullName }
        if ($files.Count -eq 0) {
            [System.Windows.MessageBox]::Show("该文件夹内没有找到支持的图片或 PDF 文件。", "提示") | Out-Null
            return
        }
        Process-InputFiles $files
    }
})

$btnReRecognize.Add_Click({
    if ($script:CurrentSourceFile -and (Test-Path $script:CurrentSourceFile)) {
        $cropRect.Visibility = [System.Windows.Visibility]::Collapsed
        Process-InputFiles @($script:CurrentSourceFile)
    } else {
        $txtStatus.Text = "当前没有已加载的图片或 PDF，请先选择、拖入或粘贴。"
    }
})

$btnStop.Add_Click({
    $script:CancelRequested = $true
    $txtStatus.Text = "正在停止，等待当前页识别完成后保留已有结果..."
})

$btnRefreshLang.Add_Click({
    Update-EngineStatusUI
    Load-LanguagesForCurrentEngine
    $txtStatus.Text = "已刷新引擎与语言状态。"
})

$btnInstallPro.Add_Click({ Start-ProEngineInstaller })

$btnInstallLang.Add_Click({
    $installer = Join-Path $script:AppDir "InstallLanguages.ps1"
    if (Test-Path $installer) {
        Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$installer`""
    }
})

$btnCopy.Add_Click({
    if (-not [string]::IsNullOrEmpty($txtResult.Text)) {
        [System.Windows.Clipboard]::SetText($txtResult.Text)
        $txtStatus.Text = "已复制到剪贴板。"
    }
})

$btnExportCsv.Add_Click({
    if ($null -eq $script:LastTableGrid -or $script:LastTableGrid.Count -eq 0) {
        [System.Windows.MessageBox]::Show("当前结果中未检测到表格数据。提示：可在左侧预览图用鼠标框选表格区域，再点击导出 CSV。", "提示") | Out-Null
        return
    }
    $sfd = New-Object Microsoft.Win32.SaveFileDialog
    $sfd.Title = "导出为 Excel 可直接打开的 CSV 表格"
    $sfd.Filter = "CSV 表格 (*.csv)|*.csv|所有文件 (*.*)|*.*"
    $sfd.FileName = "OCR_Table_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    if ($sfd.ShowDialog() -eq $true) {
        $csvText = [LocalOcrTableHelper]::FormatTable($script:LastTableGrid, "CSV")
        $utf8Bom = New-Object System.Text.UTF8Encoding($true)
        [System.IO.File]::WriteAllText($sfd.FileName, $csvText, $utf8Bom)
        $txtStatus.Text = "已导出 Excel 兼容 CSV：$($sfd.FileName)"
    }
})

$btnExportTxt.Add_Click({
    if ([string]::IsNullOrEmpty($txtResult.Text)) {
        $txtStatus.Text = "当前没有可导出的识别结果。"
        return
    }
    $sfd = New-Object Microsoft.Win32.SaveFileDialog
    $sfd.Title = "导出识别结果"
    $sfd.Filter = "文本文件 (*.txt)|*.txt|Markdown (*.md)|*.md|所有文件 (*.*)|*.*"
    $sfd.FileName = "OCR_Result_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
    if ($sfd.ShowDialog() -eq $true) {
        $utf8Bom = New-Object System.Text.UTF8Encoding($true)
        [System.IO.File]::WriteAllText($sfd.FileName, $txtResult.Text, $utf8Bom)
        $txtStatus.Text = "已导出至：$($sfd.FileName)"
    }
})

$btnClear.Add_Click({
    $txtResult.Text = ""
    $imgPreview.Source = $null
    $cropRect.Visibility = [System.Windows.Visibility]::Collapsed
    $txtPlaceholder.Visibility = [System.Windows.Visibility]::Visible
    $txtImageHeader.Text = "图片 / PDF 页面预览（可按左键直接框选区域识别）"
    $script:CurrentImagePath = $null
    $script:CurrentSourceFile = $null
    $script:LastTableGrid = $null
    $txtStatus.Text = "已清空。"
})

$window.Add_DragOver({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $e.Effects = [System.Windows.DragDropEffects]::Copy
    } else {
        $e.Effects = [System.Windows.DragDropEffects]::None
    }
    $e.Handled = $true
})

$window.Add_Drop({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
        $dropped = $e.Data.GetData([System.Windows.DataFormats]::FileDrop)
        Process-InputFiles $dropped
    }
})

$window.Add_PreviewKeyDown({
    param($s, $e)
    if ($e.Key -eq [System.Windows.Input.Key]::V -and ([System.Windows.Input.Keyboard]::Modifiers -eq [System.Windows.Input.ModifierKeys]::Control)) {
        if ([System.Windows.Clipboard]::ContainsImage()) {
            Process-ClipboardImage
            $e.Handled = $true
        }
    }
})

$window.Add_Closed({
    foreach ($tf in $script:TempFiles) {
        if (Test-Path $tf) { Remove-Item $tf -Force -ErrorAction SilentlyContinue }
    }
})

Update-EngineStatusUI
if (Test-ProEngineReady) {
    $cmbEngine.SelectedIndex = 1
} else {
    $cmbEngine.SelectedIndex = 0
}
Load-LanguagesForCurrentEngine
Update-ModeUI
[void]$window.ShowDialog()
