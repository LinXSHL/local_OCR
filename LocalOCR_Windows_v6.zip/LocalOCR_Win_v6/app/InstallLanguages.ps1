﻿# LocalOCR - Windows 原生 OCR 多语言包安装助手（含繁体中文 zh-TW / zh-HK）
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  LocalOCR v6.0 - Windows 原生 OCR 语言包安装助手" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

$languages = @(
    @{ Code = "zh-CN"; Name = "简体中文 (zh-CN)" },
    @{ Code = "zh-TW"; Name = "繁体中文-台湾 (zh-TW)" },
    @{ Code = "zh-HK"; Name = "繁体中文-香港 (zh-HK)" },
    @{ Code = "en-US"; Name = "英语 (en-US)" },
    @{ Code = "it-IT"; Name = "意大利语 (it-IT)" },
    @{ Code = "fr-FR"; Name = "法语 (fr-FR)" },
    @{ Code = "es-ES"; Name = "西班牙语 (es-ES)" },
    @{ Code = "de-DE"; Name = "德语 (de-DE)" }
)

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[提示] 请右键以“管理员身份运行”此脚本。" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}

foreach ($lang in $languages) {
    $capName = "Language.OCR~~~$($lang.Code)~0.0.1.0"
    Write-Host "正在检查: $($lang.Name) ..." -ForegroundColor White
    try {
        $cap = Get-WindowsCapability -Online -Name $capName -ErrorAction Stop
        if ($cap.State -eq "Installed") {
            Write-Host "  -> 已安装，跳过。" -ForegroundColor Green
        } else {
            Write-Host "  -> 正在下载并安装，请稍候..." -ForegroundColor Yellow
            Add-WindowsCapability -Online -Name $capName -ErrorAction Stop | Out-Null
            Write-Host "  -> 安装成功！" -ForegroundColor Green
        }
    } catch {
        Write-Host "  -> 安装失败: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "完成！请回到 LocalOCR 点击「刷新」生效。" -ForegroundColor Green
Read-Host "按回车键关闭"
