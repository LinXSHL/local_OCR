﻿# LocalOCR v6.0 - 专业离线深度学习引擎 (RapidOCR + ONNXRuntime) 一键部署助手
# 预缓存：简体中文(CH)、繁体中文(CHINESE_CHT)、英语(EN)、意法西德(LATIN)

$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$RootDir = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$VenvDir = Join-Path $RootDir "pro_venv"
$VenvPy  = Join-Path $VenvDir "Scripts\python.exe"
$Worker  = Join-Path $RootDir "app\pro_ocr_worker.py"

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "  LocalOCR v6.0 - 专业离线 OCR 引擎 (RapidOCR) 一键安装" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "说明：基于 PaddleOCR ONNX 深度学习模型，预缓存简体/繁体中文、英语与意法西德模型。" -ForegroundColor Yellow
Write-Host "提示：仅本次安装需临时联网，完成后即可完全断网离线使用。" -ForegroundColor Gray
Write-Host ""

function Find-PythonCmd {
    foreach ($candidate in @("python", "python3")) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) {
            try {
                $ver = & $cmd.Source -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
                if ($ver -match '^3\.(8|9|10|11|12|13)$') {
                    return @{ Exe = $cmd.Source; Args = @(); Ver = $ver }
                }
            } catch {}
        }
    }
    $pyLauncher = Get-Command "py" -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        foreach ($v in @("-3.11", "-3.12", "-3.10", "-3")) {
            try {
                $ver = & $pyLauncher.Source $v -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
                if ($ver -match '^3\.(8|9|10|11|12|13)$') {
                    return @{ Exe = $pyLauncher.Source; Args = @($v); Ver = $ver }
                }
            } catch {}
        }
    }
    return $null
}

$pyInfo = Find-PythonCmd
if ($null -eq $pyInfo) {
    Write-Host "[1/4] 未检测到 Python 3.8~3.13，尝试通过 Windows winget 自动安装 Python 3.11..." -ForegroundColor Yellow
    $winget = Get-Command "winget" -ErrorAction SilentlyContinue
    if ($winget) {
        & $winget.Source install -e --id Python.Python.3.11 --accept-package-agreements --accept-source-agreements
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        $pyInfo = Find-PythonCmd
    }
    if ($null -eq $pyInfo) {
        Write-Host ""
        Write-Host "[提示] 请先手动安装 Python 3.11 (https://www.python.org/downloads/)" -ForegroundColor Red
        Write-Host "       安装时务必勾选底部的「Add python.exe to PATH」，装好后重新双击 Install_ProEngine.bat。" -ForegroundColor Yellow
        Read-Host "按回车键退出"
        exit 1
    }
}

Write-Host "[1/4] 检测到 Python $($pyInfo.Ver) ($($pyInfo.Exe))" -ForegroundColor Green

if (-not (Test-Path $VenvPy)) {
    Write-Host "[2/4] 正在创建独立运行环境 pro_venv..." -ForegroundColor Cyan
    & $pyInfo.Exe @($pyInfo.Args + @("-m", "venv", $VenvDir))
    if (-not (Test-Path $VenvPy)) {
        Write-Host "[错误] 创建虚拟环境失败。" -ForegroundColor Red
        Read-Host "按回车键退出"
        exit 1
    }
} else {
    Write-Host "[2/4] 检测到已有 pro_venv，跳过创建。" -ForegroundColor Green
}

Write-Host "[3/4] 正在安装 rapidocr 与 onnxruntime（优先国内高速镜像）..." -ForegroundColor Cyan
& $VenvPy -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple --quiet 2>$null
& $VenvPy -m pip install rapidocr onnxruntime -i https://pypi.tuna.tsinghua.edu.cn/simple
if ($LASTEXITCODE -ne 0) {
    Write-Host "国内镜像失败，正在切换官方 PyPI 重试..." -ForegroundColor Yellow
    & $VenvPy -m pip install rapidocr onnxruntime
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[错误] 安装失败，请检查网络连接后重试。" -ForegroundColor Red
        Read-Host "按回车键退出"
        exit 1
    }
}

Write-Host "[4/4] 正在预下载离线模型（简中 CH、繁中 CHINESE_CHT、英语 EN、意法西德 LATIN）..." -ForegroundColor Cyan
& $VenvPy $Worker --warmup CH,CHINESE_CHT,EN,LATIN
if ($LASTEXITCODE -ne 0) {
    Write-Host "[提示] 部分模型预下载时出现波动，首次使用该语种时会自动补齐下载。" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "==============================================================" -ForegroundColor Green
Write-Host "  专业离线引擎安装完成！简/繁/英/意/法/西/德模型均已缓存。" -ForegroundColor Green
Write-Host "==============================================================" -ForegroundColor Green
Read-Host "按回车键关闭窗口"
