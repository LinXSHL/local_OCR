@echo off
chcp 65001 >nul
title LocalOCR - Install Windows OCR Language Packs (Incl. Traditional Chinese)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File "%~dp0app\InstallLanguages.ps1"'"
