@echo off
chcp 65001 >nul
title LocalOCR v6.0 - Install RapidOCR Pro Offline Engine
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\InstallProEngine.ps1"
